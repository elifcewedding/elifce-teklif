import { useState, useRef } from "react";

const GOLD = "#B8860B";
const DARKGOLD = "#8B6914";
const CREAM = "#FAF7F2";
const LIGHTGOLD = "#F5EDD6";
const CHARCOAL = "#2C2C2C";
const MUTED = "#7A7A7A";

const COMPANY = {
  name: "ElifCE Organizasyon",
  address: "Bağdat Caddesi No:466 Kat:1 Daire:3 Suadiye / Kadıköy / İstanbul",
  tel: "0216 345 49 54",
  web: "www.elifeorganizasyon.com",
};

const NOTES = [
  "Eklenen her masa bütçeye ayrıca ilave edilmektedir.",
  "Herhangi bir sözleşme yapılmadığı takdirde, verilmiş olan teklif konfirme niteliği taşımamaktadır.",
  "Fiyatlara %20 KDV dahil değildir.",
  "Ödemenin (TL) %30'u sözleşme esnasında, kalan %70'i organizasyondan 1 hafta önce kapatılmalıdır.",
];

const GEMINI_API_KEY = process.env.REACT_APP_GEMINI_API_KEY;

function formatCurrency(val) {
  if (!val) return "";
  const num = parseFloat(val.toString().replace(/[^\d.,]/g, "").replace(",", "."));
  if (isNaN(num)) return val;
  return num.toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " ₺";
}

function calcTotal(items) {
  return items.reduce((sum, item) => {
    if (!item.price) return sum;
    const n = parseFloat(item.price.toString().replace(/[^\d.,]/g, "").replace(",", "."));
    return sum + (isNaN(n) ? 0 : n);
  }, 0);
}

const css = `
  @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Jost:wght@300;400;500&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Jost', sans-serif; background: #F8F4EE; color: ${CHARCOAL}; min-height: 100vh; }
  .app { max-width: 860px; margin: 0 auto; padding: 40px 20px 80px; }

  .header { text-align: center; margin-bottom: 44px; }
  .header::before { content: ''; display: block; height: 3px; background: linear-gradient(90deg, transparent, ${GOLD}, transparent); margin-bottom: 28px; }
  .header-brand { font-family: 'Cormorant Garamond', serif; font-size: 40px; font-weight: 300; color: ${DARKGOLD}; letter-spacing: 4px; }
  .header-brand span { font-weight: 600; color: ${CHARCOAL}; }
  .header-sub { font-size: 11px; letter-spacing: 5px; text-transform: uppercase; color: ${MUTED}; margin-top: 6px; }
  .header-orn { color: ${GOLD}; font-size: 13px; margin-top: 14px; letter-spacing: 10px; }

  .card { background: white; border: 1px solid #E8DFC0; border-radius: 2px; padding: 28px; margin-bottom: 20px; position: relative; }
  .card::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px; background: linear-gradient(90deg, ${GOLD}, ${DARKGOLD}); }
  .card-title { font-family: 'Cormorant Garamond', serif; font-size: 18px; font-weight: 600; color: ${DARKGOLD}; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 22px; padding-bottom: 12px; border-bottom: 1px solid #E8DFC0; display: flex; align-items: center; gap: 10px; }
  .dot { width: 6px; height: 6px; background: ${GOLD}; transform: rotate(45deg); flex-shrink: 0; }

  .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
  .form-group { display: flex; flex-direction: column; gap: 5px; }
  .form-group.full { grid-column: 1 / -1; }
  label { font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: ${MUTED}; font-weight: 500; }
  input, textarea, select { border: 1px solid #D4C49A; border-radius: 1px; padding: 9px 13px; font-family: 'Jost', sans-serif; font-size: 14px; color: ${CHARCOAL}; background: ${CREAM}; outline: none; transition: border-color .2s, box-shadow .2s; width: 100%; }
  input:focus, textarea:focus, select:focus { border-color: ${GOLD}; box-shadow: 0 0 0 3px rgba(184,134,11,.08); background: white; }
  textarea { resize: vertical; min-height: 130px; line-height: 1.6; }

  .tabs { display: flex; border-bottom: 1px solid #E8DFC0; margin-bottom: 18px; }
  .tab { padding: 9px 18px; font-size: 11px; letter-spacing: 1.5px; text-transform: uppercase; cursor: pointer; color: ${MUTED}; border-bottom: 2px solid transparent; background: none; border-top: none; border-left: none; border-right: none; font-family: 'Jost', sans-serif; transition: all .2s; }
  .tab.active { color: ${DARKGOLD}; border-bottom-color: ${GOLD}; }
  .tab:hover:not(.active) { color: ${CHARCOAL}; }

  .items-table { width: 100%; border-collapse: collapse; }
  .items-table th { text-align: left; font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: ${MUTED}; padding: 8px 10px; border-bottom: 1px solid #E8DFC0; font-weight: 500; }
  .items-table td { padding: 4px 3px; vertical-align: middle; }
  .items-table tr:hover td { background: ${CREAM}; }
  .item-input { border: 1px solid transparent; background: transparent; padding: 7px 10px; width: 100%; font-size: 13px; font-family: 'Jost', sans-serif; border-radius: 1px; outline: none; transition: all .15s; }
  .item-input:focus { border-color: ${GOLD}; background: white; box-shadow: 0 0 0 2px rgba(184,134,11,.08); }
  .item-input.price { text-align: right; }

  .ai-badge { display: inline-flex; align-items: center; gap: 6px; font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase; color: ${GOLD}; background: ${LIGHTGOLD}; padding: 4px 10px; border-radius: 1px; margin-bottom: 10px; }
  .ai-pulse { width: 6px; height: 6px; background: ${GOLD}; border-radius: 50%; animation: pulse 1.4s infinite; }
  @keyframes pulse { 0%,100% { opacity:1; transform:scale(1); } 50% { opacity:.4; transform:scale(.7); } }

  .section-header { display: flex; align-items: center; justify-content: space-between; margin: 16px 0 8px; }
  .section-title-input { font-weight: 600; font-size: 13px; color: ${DARKGOLD}; border: none; background: transparent; letter-spacing: 1px; outline: none; border-bottom: 1px dashed ${GOLD}; padding: 2px 4px; font-family: 'Jost', sans-serif; min-width: 180px; }

  .btn { display: inline-flex; align-items: center; gap: 7px; padding: 10px 20px; font-family: 'Jost', sans-serif; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; cursor: pointer; border-radius: 1px; transition: all .2s; font-weight: 500; }
  .btn-gold { background: linear-gradient(135deg, ${GOLD}, ${DARKGOLD}); color: white; border: none; box-shadow: 0 2px 12px rgba(184,134,11,.3); }
  .btn-gold:hover { box-shadow: 0 4px 20px rgba(184,134,11,.45); transform: translateY(-1px); }
  .btn-ghost { background: transparent; color: ${DARKGOLD}; border: 1px solid ${GOLD}; }
  .btn-ghost:hover { background: ${LIGHTGOLD}; }
  .btn-sm { padding: 6px 13px; font-size: 11px; }
  .btn-remove { background: transparent; color: #ccc; border: none; cursor: pointer; font-size: 18px; padding: 4px 8px; line-height: 1; transition: color .2s; }
  .btn-remove:hover { color: #c0392b; }
  .btn-danger { background: transparent; color: #c0392b; border: 1px solid #e0b4b0; padding: 5px 10px; font-size: 11px; }
  .btn-danger:hover { background: #fff0ee; }
  .btn:disabled { opacity: .5; cursor: not-allowed; transform: none !important; }

  .grand-total { text-align: right; padding: 14px 10px 0; font-size: 14px; color: ${DARKGOLD}; font-weight: 600; letter-spacing: 1px; border-top: 2px solid ${GOLD}; margin-top: 8px; }

  .actions { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 24px; }
  .status { font-size: 12px; color: ${GOLD}; letter-spacing: 1px; display: flex; align-items: center; gap: 6px; margin-top: 10px; min-height: 20px; }

  /* ── Preview ── */
  .preview-wrap { background: white; border: 1px solid #E8DFC0; margin-top: 28px; border-radius: 2px; overflow: hidden; }
  .preview-bar { background: ${CREAM}; border-bottom: 1px solid #E8DFC0; padding: 11px 18px; display: flex; justify-content: space-between; align-items: center; }
  .preview-bar-title { font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: ${MUTED}; }
  .pdoc { padding: 44px 52px; font-family: 'Cormorant Garamond', serif; font-size: 13px; line-height: 1.75; color: ${CHARCOAL}; }
  .ptopbar { height: 4px; background: linear-gradient(90deg,${GOLD},${DARKGOLD}); margin-bottom: 28px; }
  .pname { text-align:center; font-size:30px; font-weight:300; color:${DARKGOLD}; letter-spacing:3px; margin-bottom:4px; }
  .pname strong { font-weight:600; color:${CHARCOAL}; }
  .porn { text-align:center; color:${GOLD}; font-size:12px; letter-spacing:8px; margin:8px 0; }
  .pcontact { text-align:center; font-size:11px; color:${MUTED}; font-family:'Jost',sans-serif; }
  .pdivider { height:1px; background:linear-gradient(90deg,transparent,${GOLD},transparent); margin:18px 0; }
  .pinfo { width:100%; margin:12px 0 20px; font-family:'Jost',sans-serif; font-size:12px; border-collapse:collapse; }
  .pinfo td { padding:6px 12px; }
  .pinfo tr:nth-child(odd) td { background:${LIGHTGOLD}; }
  .pinfo tr:nth-child(even) td { background:${CREAM}; }
  .pilbl { color:${DARKGOLD}; font-weight:500; width:28%; }
  .pgreeting { font-style:italic; color:${CHARCOAL}; margin-bottom:18px; font-size:13px; }
  .psectitle { font-size:14px; font-weight:600; color:${DARKGOLD}; letter-spacing:2px; text-transform:uppercase; border-left:3px solid ${GOLD}; padding-left:10px; margin:22px 0 10px; }
  .pptable { width:100%; border-collapse:collapse; font-family:'Jost',sans-serif; font-size:12px; margin-bottom:14px; }
  .pptable th { color:${GOLD}; font-size:10px; letter-spacing:2px; text-transform:uppercase; padding:7px 10px; border-bottom:2px solid ${GOLD}; }
  .pptable td { padding:8px 10px; border-bottom:1px solid #E8DFC0; }
  .pptable .ptotal td { background:${LIGHTGOLD}; color:${DARKGOLD}; font-weight:600; border-top:2px solid ${GOLD}; border-bottom:2px solid ${GOLD}; }
  .pnotes { margin-top:22px; font-family:'Jost',sans-serif; }
  .pnote { font-size:11px; color:${MUTED}; font-style:italic; margin-bottom:3px; }
  .pfooter { text-align:center; font-size:11px; color:${MUTED}; font-family:'Jost',sans-serif; margin-top:22px; padding-top:14px; border-top:1px solid ${GOLD}; }
  .pbotbar { height:4px; background:linear-gradient(90deg,${GOLD},${DARKGOLD}); margin-top:28px; }

  @media (max-width:600px) {
    .form-grid { grid-template-columns:1fr; }
    .pdoc { padding:24px 18px; }
    .app { padding:20px 14px 60px; }
  }
`;

export default function App() {
  const [client, setClient] = useState({ name: "", venue: "", date: "", guests: "", type: "Düğün" });
  const [sections, setSections] = useState([
    { id: 1, title: "Organizasyon İçeriği", items: [{ id: 2, label: "", price: "" }] }
  ]);
  const [freeText, setFreeText] = useState("");
  const [tab, setTab] = useState("tablo");
  const [parsing, setParsing] = useState(false);
  const [status, setStatus] = useState("");
  const [showPreview, setShowPreview] = useState(false);
  const nextId = useRef(100);
  const uid = () => ++nextId.current;

  const setField = (f, v) => setClient(c => ({ ...c, [f]: v }));
  const addSection = () => setSections(s => [...s, { id: uid(), title: "Yeni Bölüm", items: [{ id: uid(), label: "", price: "" }] }]);
  const removeSection = sid => setSections(s => s.filter(x => x.id !== sid));
  const setSectionTitle = (sid, t) => setSections(s => s.map(x => x.id === sid ? { ...x, title: t } : x));
  const addItem = sid => setSections(s => s.map(x => x.id === sid ? { ...x, items: [...x.items, { id: uid(), label: "", price: "" }] } : x));
  const removeItem = (sid, iid) => setSections(s => s.map(x => x.id === sid ? { ...x, items: x.items.filter(i => i.id !== iid) } : x));
  const setItem = (sid, iid, field, val) => setSections(s => s.map(x => x.id === sid ? { ...x, items: x.items.map(i => i.id === iid ? { ...i, [field]: val } : i) } : x));

  const grandTotal = calcTotal(sections.flatMap(s => s.items));

  const parseWithGemini = async () => {
    if (!freeText.trim()) return;
    setParsing(true);
    setStatus("Gemini analiz ediyor…");
    try {
      const prompt = `Sen bir düğün organizasyon teklif asistanısın. Aşağıdaki serbest metni analiz et ve JSON formatında döndür.
JSON formatı:
{
  "sections": [
    { "title": "Bölüm Adı", "items": [{ "label": "Kalem açıklaması", "price": "sadece sayı, yoksa boş string" }] }
  ]
}
Fiyatları sadece rakam olarak yaz (örn: 15000). Bölüm yoksa "Organizasyon İçeriği" kullan. SADECE JSON döndür.

Metin:
${freeText}`;

      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
        }
      );
      const data = await res.json();
      const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      if (parsed.sections) {
        setSections(parsed.sections.map(sec => ({
          id: uid(),
          title: sec.title,
          items: (sec.items || []).map(it => ({ id: uid(), label: it.label, price: it.price || "" }))
        })));
        setTab("tablo");
        setStatus("✦ Kalemler tabloya aktarıldı");
        setTimeout(() => setStatus(""), 3000);
      }
    } catch (e) {
      setStatus("Hata oluştu, lütfen tekrar dene");
      setTimeout(() => setStatus(""), 3000);
    } finally {
      setParsing(false);
    }
  };

  const handlePrint = () => {
    const sectionsHTML = sections.map(sec => {
      const validItems = sec.items.filter(i => i.label);
      if (!validItems.length) return "";
      const secTotal = calcTotal(validItems);
      return `
        <div class="psectitle">${sec.title}</div>
        <table class="pptable">
          <thead><tr><th style="text-align:left">Kalem</th><th style="text-align:right">Tutar</th></tr></thead>
          <tbody>
            ${validItems.map(it => `<tr><td>${it.label}</td><td style="text-align:right">${it.price ? formatCurrency(it.price) : "—"}</td></tr>`).join("")}
            ${secTotal > 0 ? `<tr class="ptotal"><td>Bölüm Toplamı</td><td style="text-align:right">${formatCurrency(secTotal)}</td></tr>` : ""}
          </tbody>
        </table>`;
    }).join("");

    const win = window.open("", "_blank");
    win.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8">
    <title>ElifCE Teklif - ${client.name || "Müşteri"}</title>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Jost:wght@300;400;500&display=swap');
      * { box-sizing: border-box; margin:0; padding:0; }
      body { font-family:'Jost',sans-serif; padding:40px 56px; color:#2C2C2C; }
      .ptopbar,.pbotbar { height:4px; background:linear-gradient(90deg,#B8860B,#8B6914); }
      .pbotbar { margin-top:28px; }
      .pname { text-align:center; font-family:'Cormorant Garamond',serif; font-size:30px; font-weight:300; color:#8B6914; letter-spacing:3px; margin:24px 0 4px; }
      .pname strong { font-weight:600; color:#2C2C2C; }
      .porn { text-align:center; color:#B8860B; font-size:12px; letter-spacing:8px; margin:8px 0; }
      .pcontact { text-align:center; font-size:11px; color:#7A7A7A; }
      .pdivider { height:1px; background:linear-gradient(90deg,transparent,#B8860B,transparent); margin:16px 0; }
      .pinfo { width:100%; margin:12px 0 20px; font-size:12px; border-collapse:collapse; }
      .pinfo td { padding:6px 12px; }
      .pinfo tr:nth-child(odd) td { background:#F5EDD6; }
      .pinfo tr:nth-child(even) td { background:#FAF7F2; }
      .pilbl { color:#8B6914; font-weight:500; width:28%; }
      .pgreeting { font-style:italic; font-family:'Cormorant Garamond',serif; font-size:13px; margin-bottom:16px; }
      .psectitle { font-family:'Cormorant Garamond',serif; font-size:14px; font-weight:600; color:#8B6914; letter-spacing:2px; text-transform:uppercase; border-left:3px solid #B8860B; padding-left:10px; margin:20px 0 10px; }
      .pptable { width:100%; border-collapse:collapse; font-size:12px; margin-bottom:12px; }
      .pptable th { color:#B8860B; font-size:10px; letter-spacing:2px; text-transform:uppercase; padding:7px 10px; border-bottom:2px solid #B8860B; text-align:left; }
      .pptable td { padding:8px 10px; border-bottom:1px solid #E8DFC0; }
      .ptotal td { background:#F5EDD6; color:#8B6914; font-weight:600; border-top:2px solid #B8860B; border-bottom:2px solid #B8860B; }
      .grandtotal { margin-top:8px; }
      .grandtotal td { font-size:14px; }
      .pnote { font-size:11px; color:#7A7A7A; font-style:italic; margin-bottom:3px; }
      .pnotes { margin-top:20px; }
      .pfooter { text-align:center; font-size:11px; color:#7A7A7A; margin-top:20px; padding-top:12px; border-top:1px solid #B8860B; }
      @media print { body { padding:20px 36px; } }
    </style></head><body>
    <div class="ptopbar"></div>
    <div class="pname"><strong>ElifCE</strong> Organizasyon</div>
    <div class="porn">✦ &nbsp; ✦ &nbsp; ✦</div>
    <div class="pcontact">${COMPANY.address}</div>
    <div class="pcontact">${COMPANY.tel} · ${COMPANY.web}</div>
    <div class="pdivider"></div>
    <table class="pinfo"><tbody>
      <tr><td class="pilbl">İletişim</td><td>${client.name || "—"}</td></tr>
      <tr><td class="pilbl">Mekan</td><td>${client.venue || "—"}</td></tr>
      <tr><td class="pilbl">Kişi Sayısı</td><td>${client.guests || "—"}</td></tr>
      <tr><td class="pilbl">Tarih</td><td>${client.date || "—"}</td></tr>
    </tbody></table>
    <div class="pgreeting">Görüşmemize istinaden ${client.type === "Düğün" ? "düğün organizasyonunuz" : "organizasyonunuz"} için hazırlamış olduğumuz teklif çalışmasını özenle sizlerle paylaşıyoruz.</div>
    ${sectionsHTML}
    ${grandTotal > 0 ? `<table class="pptable grandtotal"><tbody><tr class="ptotal"><td>GENEL TOPLAM</td><td style="text-align:right">${formatCurrency(grandTotal)}</td></tr></tbody></table>` : ""}
    <div class="pnotes">${NOTES.map(n => `<div class="pnote">* ${n}</div>`).join("")}</div>
    <div class="pfooter">${COMPANY.address} · ${COMPANY.tel} · ${COMPANY.web}</div>
    <div class="pbotbar"></div>
    </body></html>`);
    win.document.close();
    setTimeout(() => { win.focus(); win.print(); }, 600);
  };

  return (
    <>
      <style>{css}</style>
      <div className="app">

        {/* Header */}
        <div className="header">
          <div className="header-brand">Elif<span>CE</span></div>
          <div className="header-sub">Organizasyon · Teklif Sistemi</div>
          <div className="header-orn">✦ &nbsp; ✦ &nbsp; ✦</div>
        </div>

        {/* Müşteri Bilgileri */}
        <div className="card">
          <div className="card-title"><div className="dot" /> Müşteri Bilgileri</div>
          <div className="form-grid">
            <div className="form-group">
              <label>Etkinlik Türü</label>
              <select value={client.type} onChange={e => setField("type", e.target.value)}>
                <option>Düğün</option><option>Mezuniyet</option><option>Nişan</option><option>Kına</option><option>Özel Etkinlik</option>
              </select>
            </div>
            <div className="form-group">
              <label>İletişim (Ad Soyad)</label>
              <input placeholder="Örn: Ayşe Hanım & Mehmet Bey" value={client.name} onChange={e => setField("name", e.target.value)} />
            </div>
            <div className="form-group">
              <label>Mekan</label>
              <input placeholder="Örn: Büyük Kulüp Kış Bahçesi" value={client.venue} onChange={e => setField("venue", e.target.value)} />
            </div>
            <div className="form-group">
              <label>Tarih</label>
              <input placeholder="Örn: 26 Haziran 2026" value={client.date} onChange={e => setField("date", e.target.value)} />
            </div>
            <div className="form-group">
              <label>Kişi Sayısı</label>
              <input placeholder="Örn: 300" value={client.guests} onChange={e => setField("guests", e.target.value)} />
            </div>
          </div>
        </div>

        {/* Hizmet Kalemleri */}
        <div className="card">
          <div className="card-title"><div className="dot" /> Hizmet Kalemleri</div>
          <div className="tabs">
            <button className={`tab ${tab === "tablo" ? "active" : ""}`} onClick={() => setTab("tablo")}>Tablo Giriş</button>
            <button className={`tab ${tab === "serbest" ? "active" : ""}`} onClick={() => setTab("serbest")}>Serbest Metin → AI</button>
          </div>

          {tab === "serbest" && (
            <div>
              <div className="ai-badge"><div className="ai-pulse" /> Gemini AI · Otomatik Çeviri</div>
              <textarea
                placeholder={"Toplantı notlarını veya hizmet listesini buraya yapıştır…\n\nÖrnek:\n15 adet yuvarlak masa çiçek ve mum supla 97500 TL\nVinil pist kaplama 20000\nBaskılar:\nSahne arkası yazı 16000 TL"}
                value={freeText}
                onChange={e => setFreeText(e.target.value)}
              />
              <div style={{ marginTop: 12, display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                <button className="btn btn-gold btn-sm" onClick={parseWithGemini} disabled={parsing || !freeText.trim()}>
                  {parsing ? "Analiz ediliyor…" : "✦  Tabloya Dönüştür"}
                </button>
                {status && <span className="status">{status}</span>}
              </div>
            </div>
          )}

          {tab === "tablo" && (
            <div>
              {sections.map((sec, si) => (
                <div key={sec.id}>
                  <div className="section-header">
                    <input
                      className="section-title-input"
                      value={sec.title}
                      onChange={e => setSectionTitle(sec.id, e.target.value)}
                    />
                    <div style={{ display: "flex", gap: 8 }}>
                      <button className="btn btn-ghost btn-sm" onClick={() => addItem(sec.id)}>+ Kalem</button>
                      {sections.length > 1 && <button className="btn btn-danger btn-sm" onClick={() => removeSection(sec.id)}>✕ Bölüm</button>}
                    </div>
                  </div>
                  <table className="items-table">
                    <thead>
                      <tr>
                        <th style={{ width: "68%" }}>Açıklama</th>
                        <th style={{ width: "24%", textAlign: "right" }}>Tutar (₺)</th>
                        <th style={{ width: "8%" }} />
                      </tr>
                    </thead>
                    <tbody>
                      {sec.items.map(item => (
                        <tr key={item.id}>
                          <td><input className="item-input" placeholder="Kalem açıklaması…" value={item.label} onChange={e => setItem(sec.id, item.id, "label", e.target.value)} /></td>
                          <td><input className="item-input price" placeholder="0,00" value={item.price} onChange={e => setItem(sec.id, item.id, "price", e.target.value)} /></td>
                          <td style={{ textAlign: "center" }}>
                            {sec.items.length > 1 && <button className="btn-remove" onClick={() => removeItem(sec.id, item.id)}>×</button>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ))}

              {grandTotal > 0 && (
                <div className="grand-total">Genel Toplam: {formatCurrency(grandTotal)}</div>
              )}

              <div style={{ marginTop: 16 }}>
                <button className="btn btn-ghost btn-sm" onClick={addSection}>+ Bölüm Ekle</button>
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="actions">
          <button className="btn btn-ghost" onClick={() => setShowPreview(p => !p)}>
            {showPreview ? "Önizlemeyi Kapat" : "✦  Önizle"}
          </button>
          <button className="btn btn-gold" onClick={handlePrint}>
            ⬇  PDF / Yazdır
          </button>
        </div>

        {/* Preview */}
        {showPreview && (
          <div className="preview-wrap">
            <div className="preview-bar">
              <span className="preview-bar-title">Teklif Önizleme</span>
              <span style={{ fontSize: 11, color: MUTED }}>Görseller temsilidir</span>
            </div>
            <div className="pdoc">
              <div className="ptopbar" />
              <div className="pname"><strong>ElifCE</strong> Organizasyon</div>
              <div className="porn">✦ &nbsp; ✦ &nbsp; ✦</div>
              <div className="pcontact">{COMPANY.address}</div>
              <div className="pcontact">{COMPANY.tel} · {COMPANY.web}</div>
              <div className="pdivider" />
              <table className="pinfo"><tbody>
                <tr><td className="pilbl">İletişim</td><td>{client.name || "—"}</td></tr>
                <tr><td className="pilbl">Mekan</td><td>{client.venue || "—"}</td></tr>
                <tr><td className="pilbl">Kişi Sayısı</td><td>{client.guests || "—"}</td></tr>
                <tr><td className="pilbl">Tarih</td><td>{client.date || "—"}</td></tr>
              </tbody></table>
              <div className="pgreeting">
                Görüşmemize istinaden {client.type === "Düğün" ? "düğün organizasyonunuz" : "organizasyonunuz"} için hazırlamış olduğumuz teklif çalışmasını özenle sizlerle paylaşıyoruz.
              </div>
              {sections.map(sec => {
                const valid = sec.items.filter(i => i.label);
                if (!valid.length) return null;
                const st = calcTotal(valid);
                return (
                  <div key={sec.id}>
                    <div className="psectitle">{sec.title}</div>
                    <table className="pptable">
                      <thead><tr><th style={{textAlign:"left"}}>Kalem</th><th style={{textAlign:"right"}}>Tutar</th></tr></thead>
                      <tbody>
                        {valid.map(it => <tr key={it.id}><td>{it.label}</td><td style={{textAlign:"right"}}>{it.price ? formatCurrency(it.price) : "—"}</td></tr>)}
                        {st > 0 && <tr className="ptotal"><td>Bölüm Toplamı</td><td style={{textAlign:"right"}}>{formatCurrency(st)}</td></tr>}
                      </tbody>
                    </table>
                  </div>
                );
              })}
              {grandTotal > 0 && (
                <table className="pptable grandtotal"><tbody>
                  <tr className="ptotal"><td style={{fontSize:14}}>GENEL TOPLAM</td><td style={{textAlign:"right",fontSize:14}}>{formatCurrency(grandTotal)}</td></tr>
                </tbody></table>
              )}
              <div className="pnotes">{NOTES.map((n, i) => <div key={i} className="pnote">* {n}</div>)}</div>
              <div className="pfooter">{COMPANY.address} · {COMPANY.tel} · {COMPANY.web}</div>
              <div className="pbotbar" />
            </div>
          </div>
        )}

      </div>
    </>
  );
}
